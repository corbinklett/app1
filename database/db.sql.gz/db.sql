-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: smorg
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `id_activity` int(11) NOT NULL AUTO_INCREMENT,
  `id_member` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `description` varchar(140) DEFAULT NULL,
  `photo` varchar(45) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_activity`),
  KEY `FK_activity_member_idx` (`id_member`),
  CONSTRAINT `FK_activity_member` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
INSERT INTO `activity` VALUES (1,26,'Centennial Olympic Park','Stroll through Atlanta\'s gangsta park to the tune of a classic like IAMDABES.',NULL,'2013-07-08 22:00:47'),(2,27,'Dancing Goats Coffeehouse','Trendy coffee shop in the new Ponce City Market.',NULL,'2013-07-08 22:00:48'),(3,26,'Goat Farm','Historic venue with coffee shop and performances. Schedule: https://www.facebook.com/TheGoatFarmArtsCenter',NULL,'2013-07-08 22:00:48'),(4,30,'Chattahoochee River','Access point for tubing & coffee @ Walton on the Chattahoochee.',NULL,'2013-07-08 22:00:48'),(6,32,'Piedmont Park','Atlanta\'s best park. Also check out Park Tavern.',NULL,'2013-07-08 22:00:49'),(7,29,'Atlanta Quarry','Not necessarily legal, but fun to swim in.',NULL,'2013-07-08 22:00:49'),(8,31,'Stone Mountain','Huge granite mountain for climbing. Also, amazing fireworks and laser shows.',NULL,'2013-07-08 22:00:49');
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id_city` int(11) NOT NULL AUTO_INCREMENT,
  `cityname` varchar(45) DEFAULT NULL,
  `id_activity` int(11) NOT NULL,
  `timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_city`),
  KEY `idx_cityname` (`cityname`),
  KEY `FK_city_activity_idx` (`id_activity`),
  CONSTRAINT `FK_city_activity` FOREIGN KEY (`id_activity`) REFERENCES `activity` (`id_activity`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'atlanta',1,NULL),(2,'atlanta',2,NULL),(3,'atlanta',3,NULL),(4,'atlanta',4,NULL),(5,'atlanta',6,NULL),(6,'atlanta',7,NULL),(7,'atlanta',8,NULL);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation`
--

DROP TABLE IF EXISTS `conversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversation` (
  `id_conversation` int(11) NOT NULL AUTO_INCREMENT,
  `id_activity` int(11) NOT NULL,
  `id_member_sender` int(11) NOT NULL,
  `share_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_conversation`),
  KEY `sender` (`id_member_sender`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation`
--

LOCK TABLES `conversation` WRITE;
/*!40000 ALTER TABLE `conversation` DISABLE KEYS */;
INSERT INTO `conversation` VALUES (1,3,26,'2013-08-13 14:07:31'),(2,6,26,'2013-08-13 20:25:07'),(4,7,26,'2013-11-21 04:05:42'),(5,7,26,'2013-11-22 22:57:51');
/*!40000 ALTER TABLE `conversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite` (
  `id_favorite` int(11) NOT NULL AUTO_INCREMENT,
  `id_member` int(11) NOT NULL,
  `id_activity` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_favorite`),
  KEY `FK_favorite_member_idx` (`id_member`),
  KEY `FK_favorite_activity_idx` (`id_activity`),
  CONSTRAINT `FK_favorite_member` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_favorite_activity` FOREIGN KEY (`id_activity`) REFERENCES `activity` (`id_activity`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
INSERT INTO `favorite` VALUES (1,26,4,'2013-07-09 01:52:19'),(2,26,1,'2013-07-09 03:05:01'),(3,27,3,'2013-07-09 03:06:06'),(4,27,2,'2013-07-09 14:49:47'),(5,27,8,'2013-07-09 14:50:10'),(6,27,6,'2013-07-09 15:37:47'),(7,27,7,'2013-07-09 23:40:27'),(8,26,7,'2013-07-10 16:48:22'),(9,26,8,'2013-07-11 03:06:56'),(10,26,2,'2013-07-11 15:51:50'),(11,26,6,'2013-07-11 17:26:24'),(12,30,8,'2013-07-13 21:55:24'),(13,28,6,'2013-07-14 20:16:07'),(14,26,3,'2013-07-16 22:46:34'),(15,32,7,'2013-07-30 14:11:54'),(16,32,3,'2013-07-30 14:17:30');
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `friendship`
--

DROP TABLE IF EXISTS `friendship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `friendship` (
  `id_friendship` int(11) NOT NULL AUTO_INCREMENT,
  `id_member` int(11) NOT NULL,
  `id_member_friend` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_friendship`),
  KEY `FK_friendship_member_idx` (`id_member`),
  CONSTRAINT `FK_friendship_member` FOREIGN KEY (`id_member`) REFERENCES `member` (`id_member`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friendship`
--

LOCK TABLES `friendship` WRITE;
/*!40000 ALTER TABLE `friendship` DISABLE KEYS */;
INSERT INTO `friendship` VALUES (2,26,28),(7,27,26),(8,27,28),(9,27,29),(10,27,30),(11,27,31),(12,27,32),(13,28,26),(14,28,27),(15,28,29),(16,28,30),(17,28,31),(18,28,32),(19,29,26),(20,29,27),(21,29,28),(22,29,30),(23,29,31),(24,29,32),(25,30,26),(26,30,27),(27,30,28),(28,30,29),(29,30,31),(30,30,32),(31,31,26),(32,31,27),(33,31,28),(34,31,29),(35,31,30),(36,31,32),(37,32,26),(38,32,27),(39,32,28),(40,32,29),(41,32,30),(42,32,31),(43,26,32),(44,26,31),(45,26,27),(46,26,30),(51,26,29);
/*!40000 ALTER TABLE `friendship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodfor`
--

DROP TABLE IF EXISTS `goodfor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goodfor` (
  `id_goodfor` int(11) NOT NULL AUTO_INCREMENT,
  `id_tag` int(11) DEFAULT NULL,
  `id_activity` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_goodfor`),
  KEY `index_id_activity` (`id_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodfor`
--

LOCK TABLES `goodfor` WRITE;
/*!40000 ALTER TABLE `goodfor` DISABLE KEYS */;
INSERT INTO `goodfor` VALUES (1,5,1,'2013-07-29 15:01:19'),(2,22,1,'2013-07-29 15:01:19'),(3,20,1,'2013-07-29 15:01:19'),(4,7,2,'2013-07-29 15:01:19'),(5,16,2,'2013-07-29 15:01:19'),(6,17,2,'2013-07-29 15:01:19'),(7,10,3,'2013-07-29 15:01:19'),(8,23,3,'2013-07-29 15:01:19'),(9,13,3,'2013-07-29 15:01:19'),(10,3,3,'2013-07-29 15:01:19'),(11,7,4,'2013-07-29 15:01:19'),(12,1,4,'2013-07-29 15:01:19'),(13,21,4,'2013-07-29 15:01:19'),(14,10,4,'2013-07-29 15:01:19'),(15,5,6,'2013-07-29 15:01:19'),(16,12,6,'2013-07-29 15:01:19'),(17,18,6,'2013-07-29 15:01:19'),(18,15,7,'2013-07-29 15:01:19'),(19,14,7,'2013-07-29 15:01:19'),(20,1,7,'2013-07-29 15:01:19'),(21,11,8,'2013-07-29 15:01:19'),(22,6,8,'2013-07-29 15:01:19'),(23,20,8,'2013-07-29 15:01:19');
/*!40000 ALTER TABLE `goodfor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id_member` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(18) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `email` varchar(56) NOT NULL,
  `firstname` varchar(56) NOT NULL,
  `lastname` varchar(56) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `about` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`id_member`),
  KEY `user` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (26,'corbinklett','fbe338e1b9c150f3b9a778a1cd4641fd6fa37ef4','corbinklett@gmail.com','Corbin','Klett','2013-07-10 22:57:08','Just here to party.'),(27,'vollo','aaa9f5dd75ae407205951e1b5f94ef4627f13d5b','chrisvollo@gmail.com','Chris','Vollo','2013-07-10 22:57:09','I think that everyone should be happy.'),(28,'thekody','b1b56a068411b988fb53fe2328c30e2ffecf0767','kody.dahl@gmail.com','Kody','Dahl','2013-07-10 22:57:10','What would I ever do without vsco.'),(29,'scottfreakingtoomb','aa582356bb788baee52e5f741f9b9f9bb06fee87','scott.toombs@gmail.com','Scott','Toombs','2013-07-10 22:57:08','IAMDEBES.'),(30,'jtsmooth','7f81d68ad2e39b2dd0d370478808bab8a5bf4ca4','emailjeremythomas@gmail.com','Jeremy','Thomas','2013-07-10 22:57:10','Naturally.'),(31,'kelsayyy','2b1783c7f1901bb45a81e3a0cd8f99fbd663e3af','kelsaylewis@gmail.com','Kelsay','Lewis','2013-07-10 22:57:10','I no longer work for smorg!'),(32,'mcspross','587ae4ac00893f4c294f0f73e8f7d86e993ab861','m.c.spross@gmail.com','Colton','Spross','2013-07-10 22:59:16','AHHHHHHH!'),(34,'testuser','5a7e427c19f0af7177c4e06535d58318556366c6','test@test.com','test','test','2013-07-28 22:19:56',NULL),(35,'test2','ac42549d1b8fd04ea075c5c0e42d423c212e7830','test2@tes.com','testuser2','test2','2013-07-28 22:21:05',NULL),(36,'username','f88318c7b08d5703b89d1af24ddf300d13dd3c4b','user@email.com','New','User','2013-07-29 13:40:58',NULL),(37,'nihunt','5d35ccb486b0b9f924b14e7c0df083794f9945eb','nickht88@gmail.com','Nick','Hunt','2013-08-14 03:04:10',NULL),(38,'doufer','00d65ce37eee49eaead9fa3320fe085dfd747ab8','kody.dahl@gmail.com','Doofus','Brannigan','2013-08-30 00:48:29',NULL),(39,'jsh5','e5510896e85be173c1ff977ee438e9521b10acfb','jsh5@gmail.com','joe','shoe','2013-10-08 00:41:18',NULL),(40,';lkj','211f6cd3b1d5f7f12b6680056e32934aa806ccc4',';lkj',';lkj',';l;kj','2013-10-08 00:45:58',NULL),(41,'lkjh','4ae83e2139851125c3ce15ab02dea541a374d8c5','lkjh','kjh','kljh','2013-10-08 00:48:25',NULL),(42,'sdf','2d5ee6243f66699a9fa71733ab100934c535b7e5','sdf','sdf','sdf','2013-10-08 00:50:44',NULL),(43,'asdg','709be0f951e66af960d1d6e116b71b7337890494','24','sdg','asdg','2013-10-08 00:52:12',NULL),(44,'erger','defd513830832d928a36e16b96aecd37a84eed56','erbwerb','asfh','reer','2013-10-08 00:52:54',NULL),(45,'ertert','ce4b38c5dfba63f21934ee9119a150fcdd85f3be','ertert','ewert','ertert','2013-10-08 00:54:18',NULL),(46,'weew','d507eea9e8f267825af29c7a04f1d18983c57ef2','wewewe','wwewe','wewew','2013-10-08 00:54:50',NULL),(47,'sdfgsdfh','1fc616469ffb0120cc29b0aaa781419008969eb0','sdfhsdfh','sgsfg','fgdsfg','2013-10-08 00:56:08',NULL),(48,'erreerer','5ee944af8f4619bde90fb08f3d61406145b44033','reer','asdgas','shh','2013-10-08 00:56:42',NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(11) NOT NULL,
  `id_member_sender` int(11) NOT NULL,
  `message_text` text,
  `message_sent_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_message`),
  KEY `conversation` (`id_conversation`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,1,26,'Hey guys, let\'s do this!','2013-08-13 14:08:21'),(2,1,27,'ok :p','2013-08-13 14:09:21'),(3,2,26,'Football at the park on Saturday?','2013-08-13 20:26:46'),(4,2,31,'I can after 12','2013-08-13 20:27:47'),(5,2,32,'ok 1pm it is.','2013-08-13 20:28:47'),(7,4,26,'test message!! adventure!!','2013-11-21 04:05:43'),(8,1,26,'test new message here','2013-11-21 19:50:25'),(9,4,26,'and new msg here?','2013-11-21 19:50:35'),(10,5,26,'lets do this saturyda','2013-11-22 22:57:51'),(11,5,26,'asfd;lkjs','2013-11-22 22:58:13');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shared`
--

DROP TABLE IF EXISTS `shared`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shared` (
  `id_shared` int(11) NOT NULL AUTO_INCREMENT,
  `id_conversation` int(11) NOT NULL,
  `id_member_participant` int(11) NOT NULL,
  `shared_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_shared`),
  KEY `conversation` (`id_conversation`),
  KEY `participant` (`id_member_participant`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shared`
--

LOCK TABLES `shared` WRITE;
/*!40000 ALTER TABLE `shared` DISABLE KEYS */;
INSERT INTO `shared` VALUES (1,1,26,'2013-08-13 14:07:52'),(2,1,27,'2013-08-13 14:07:53'),(3,1,28,'2013-08-13 14:07:53'),(4,2,26,'2013-08-13 20:25:38'),(5,2,27,'2013-08-13 20:25:38'),(6,2,28,'2013-08-13 20:25:38'),(7,2,31,'2013-08-13 20:25:39'),(8,2,32,'2013-08-13 20:25:39'),(11,4,26,'2013-11-21 04:05:42'),(12,4,29,'2013-11-21 04:05:42'),(13,4,28,'2013-11-21 04:05:43'),(14,5,26,'2013-11-22 22:57:51'),(15,5,28,'2013-11-22 22:57:51'),(16,5,29,'2013-11-22 22:57:51');
/*!40000 ALTER TABLE `shared` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id_tag` int(11) NOT NULL AUTO_INCREMENT,
  `tag_text` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tag`),
  KEY `tag_index` (`tag_text`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'adventure','0000-00-00 00:00:00'),(3,'artsy','0000-00-00 00:00:00'),(5,'cityviews','0000-00-00 00:00:00'),(6,'climbing','0000-00-00 00:00:00'),(7,'coffee','0000-00-00 00:00:00'),(10,'dates','0000-00-00 00:00:00'),(11,'family','0000-00-00 00:00:00'),(12,'festivals','0000-00-00 00:00:00'),(13,'hipster','0000-00-00 00:00:00'),(14,'illicit','0000-00-00 00:00:00'),(15,'photoshoot','0000-00-00 00:00:00'),(16,'reading','0000-00-00 00:00:00'),(17,'relaxing','0000-00-00 00:00:00'),(18,'sports','0000-00-00 00:00:00'),(20,'tourism','0000-00-00 00:00:00'),(21,'tubing','0000-00-00 00:00:00'),(22,'walking','0000-00-00 00:00:00'),(23,'weekends','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-02-03 23:43:37
